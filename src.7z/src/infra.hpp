#ifndef INFRA_H
#define INFRA_H

#include <stdio.h>
#include <assert.h>
#include "common/xf_types.h"
#include "hls_stream.h"
#include "common/xf_axi_sdata.h"
#include "common/xf_axi_io.h"
#include "common/xf_structs.h"
#include "common/xf_infra.h"

template<int W,int T,int ROWS, int COLS,int NPC>
void plainStream2xfMat(hls::stream< ap_axiu<W,1,1,1> >& in_strm, xf::Mat<T,ROWS, COLS, NPC>& img)
{
#pragma hls inline

    int res = 0,val=0,depth;
    ap_axiu<W,1,1,1> axi;
    xf::Scalar<XF_CHANNELS(T,NPC), XF_TNAME(T,NPC)> pix;
     depth = XF_WORDDEPTH(XF_WORDWIDTH(T,NPC));
//    HLS_SIZE_T rows = img.rows;
//    HLS_SIZE_T cols = img.cols;
    int rows = img.rows;
    int cols = img.cols;
    assert(rows <= ROWS);
    assert(cols <= COLS);
 loop_height: for (int i = 0; i < rows; i++) {
    loop_width: for (int j = 0; j < (cols/NPC); j++) {
#pragma HLS loop_flatten off
#pragma HLS pipeline II=1
           in_strm >> axi;

           xf:: AXIGetBitFields(axi, 0, depth, pix.val[0]);

           xf::fetchingmatdata< T, ROWS,  COLS, NPC>(img, pix,val);
           val++;
        }
    }
}
template<int W, int T, int ROWS, int COLS,int NPC>
void xfMat2plainStream(xf::Mat<T,ROWS, COLS,NPC>& img,hls::stream<ap_axiu<W,1,1,1> >& out_strm)
{
#pragma hls inline
    int res = 0,index=0,depth;
    xf::Scalar<XF_CHANNELS(T,NPC), XF_TNAME(T,NPC)> pix;
    ap_axiu<W,1,1,1> axi;
     depth =XF_WORDDEPTH(XF_WORDWIDTH(T,NPC));//8;// HLS_TBITDEPTH(T);

    // std::cout << W << " " << depth << " " << HLS_MAT_CN(T) << "\n";
    assert(W >= depth*HLS_MAT_CN(T) && "Bit-Width of AXI stream must be greater than the total number of bits in a pixel");
//    HLS_SIZE_T rows = img.rows;
//    HLS_SIZE_T cols = img.cols;
    int rows = img.rows;
    int cols = img.cols;
    assert(rows <= ROWS);
    assert(cols <= COLS);
    bool sof = 1;
 loop_height: for (int i = 0; i < rows; i++) {
    loop_width: for (int j = 0; j < (cols/NPC); j++) {
#pragma HLS loop_flatten off
#pragma HLS pipeline II=1
            if (sof) {
                axi.user = 1;
                sof = 0;

            } else {
                axi.user = 0;
            }
            if (j == (cols-1) && i == (rows - 1)) {
                axi.last = 1;
            } else {
                axi.last = 0;
            }
            xf::fillingdata< T, ROWS,  COLS, NPC>(img, pix,index);
            index++;
            axi.data = -1;

                xf::AXISetBitFields(axi, 0, depth, pix.val[0]);
            axi.keep = -1;
            out_strm << axi;
        }
    }
}

#endif
