// ==============================================================
// File generated on Mon Aug 03 11:01:38 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xrect_draw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XRect_draw_CfgInitialize(XRect_draw *InstancePtr, XRect_draw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->Return_BaseAddress = ConfigPtr->Return_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XRect_draw_Start(XRect_draw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_AP_CTRL) & 0x80;
    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_AP_CTRL, Data | 0x01);
}

u32 XRect_draw_IsDone(XRect_draw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XRect_draw_IsIdle(XRect_draw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XRect_draw_IsReady(XRect_draw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XRect_draw_EnableAutoRestart(XRect_draw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_AP_CTRL, 0x80);
}

void XRect_draw_DisableAutoRestart(XRect_draw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_AP_CTRL, 0);
}

void XRect_draw_Set_rect_data(XRect_draw *InstancePtr, XRect_draw_Rect_data Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRect_draw_WriteReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 0, Data.word_0);
    XRect_draw_WriteReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 4, Data.word_1);
    XRect_draw_WriteReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 8, Data.word_2);
    XRect_draw_WriteReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 12, Data.word_3);
}

XRect_draw_Rect_data XRect_draw_Get_rect_data(XRect_draw *InstancePtr) {
    XRect_draw_Rect_data Data;

    Data.word_0 = XRect_draw_ReadReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 0);
    Data.word_1 = XRect_draw_ReadReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 4);
    Data.word_2 = XRect_draw_ReadReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 8);
    Data.word_3 = XRect_draw_ReadReg(InstancePtr->Return_BaseAddress, XRECT_DRAW_RETURN_ADDR_RECT_DATA_DATA + 12);
    return Data;
}

void XRect_draw_InterruptGlobalEnable(XRect_draw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_GIE, 1);
}

void XRect_draw_InterruptGlobalDisable(XRect_draw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_GIE, 0);
}

void XRect_draw_InterruptEnable(XRect_draw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_IER);
    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_IER, Register | Mask);
}

void XRect_draw_InterruptDisable(XRect_draw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_IER);
    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_IER, Register & (~Mask));
}

void XRect_draw_InterruptClear(XRect_draw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRect_draw_WriteReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_ISR, Mask);
}

u32 XRect_draw_InterruptGetEnabled(XRect_draw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_IER);
}

u32 XRect_draw_InterruptGetStatus(XRect_draw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRect_draw_ReadReg(InstancePtr->Axilites_BaseAddress, XRECT_DRAW_AXILITES_ADDR_ISR);
}

