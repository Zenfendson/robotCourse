// ==============================================================
// File generated on Mon Aug 03 11:01:38 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XRECT_DRAW_H
#define XRECT_DRAW_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xrect_draw_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Axilites_BaseAddress;
    u32 Return_BaseAddress;
} XRect_draw_Config;
#endif

typedef struct {
    u32 Axilites_BaseAddress;
    u32 Return_BaseAddress;
    u32 IsReady;
} XRect_draw;

typedef struct {
    u32 word_0;
    u32 word_1;
    u32 word_2;
    u32 word_3;
} XRect_draw_Rect_data;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XRect_draw_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XRect_draw_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XRect_draw_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XRect_draw_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XRect_draw_Initialize(XRect_draw *InstancePtr, u16 DeviceId);
XRect_draw_Config* XRect_draw_LookupConfig(u16 DeviceId);
int XRect_draw_CfgInitialize(XRect_draw *InstancePtr, XRect_draw_Config *ConfigPtr);
#else
int XRect_draw_Initialize(XRect_draw *InstancePtr, const char* InstanceName);
int XRect_draw_Release(XRect_draw *InstancePtr);
#endif

void XRect_draw_Start(XRect_draw *InstancePtr);
u32 XRect_draw_IsDone(XRect_draw *InstancePtr);
u32 XRect_draw_IsIdle(XRect_draw *InstancePtr);
u32 XRect_draw_IsReady(XRect_draw *InstancePtr);
void XRect_draw_EnableAutoRestart(XRect_draw *InstancePtr);
void XRect_draw_DisableAutoRestart(XRect_draw *InstancePtr);

void XRect_draw_Set_rect_data(XRect_draw *InstancePtr, XRect_draw_Rect_data Data);
XRect_draw_Rect_data XRect_draw_Get_rect_data(XRect_draw *InstancePtr);

void XRect_draw_InterruptGlobalEnable(XRect_draw *InstancePtr);
void XRect_draw_InterruptGlobalDisable(XRect_draw *InstancePtr);
void XRect_draw_InterruptEnable(XRect_draw *InstancePtr, u32 Mask);
void XRect_draw_InterruptDisable(XRect_draw *InstancePtr, u32 Mask);
void XRect_draw_InterruptClear(XRect_draw *InstancePtr, u32 Mask);
u32 XRect_draw_InterruptGetEnabled(XRect_draw *InstancePtr);
u32 XRect_draw_InterruptGetStatus(XRect_draw *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
