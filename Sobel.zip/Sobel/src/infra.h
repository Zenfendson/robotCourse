#ifndef INFRA_H
#define INFRA_H

#include <stdio.h>
#include <assert.h>
#include "common/xf_types.h"
#include "hls_stream.h"
#include "ap_axi_sdata.h"
#include "common/xf_axi_io.h"
#include "common/xf_structs.h"

#ifndef WIDTH
#define WIDTH 	1280
#endif

#ifndef HEIGHT
#define HEIGHT	720
#endif

template<int W, int T, int ROWS, int COLS,int NPC>
void plainStream2xfMat(hls::stream< ap_axiu<W,1,1,1> >& in_strm, xf::Mat<T,ROWS, COLS, NPC>& img);

template<int W, int T, int ROWS, int COLS,int NPC>
void xfMat2plainStream(xf::Mat<T,ROWS, COLS,NPC>& img,hls::stream<ap_axiu<W,1,1,1> >& out_strm);

#endif
