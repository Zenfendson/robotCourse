#include "Sobel_accel.h"
#include "infra.h"
#include "imgproc/xf_sobel.hpp"
#include "imgproc/xf_cvt_color.hpp"

void select(xf::Mat<XF_8UC1,HEIGHT, WIDTH,XF_NPPC1>& img_gray_x, xf::Mat<XF_8UC1,HEIGHT, WIDTH,XF_NPPC1>& img_gray_y, xf::Mat<XF_8UC3,HEIGHT, WIDTH,XF_NPPC1>& img_out,int order) {
	if(order == 1)
		xf::xfgray2rgb<XF_8UC1, XF_8UC3, HEIGHT, WIDTH, XF_NPPC1, XF_WORDWIDTH(XF_8UC1,XF_NPPC1),XF_WORDWIDTH(XF_8UC3,XF_NPPC1), (WIDTH >> XF_BITSHIFT(XF_NPPC1)) >
		(img_gray_y, img_out, img_out.rows,img_out.cols);
	else
		xf::xfgray2rgb<XF_8UC1, XF_8UC3, HEIGHT, WIDTH, XF_NPPC1, XF_WORDWIDTH(XF_8UC1,XF_NPPC1),XF_WORDWIDTH(XF_8UC3,XF_NPPC1), (WIDTH >> XF_BITSHIFT(XF_NPPC1)) >
		(img_gray_x, img_out, img_out.rows,img_out.cols);
}


void Sobel_accel(hls::stream<ap_axiu<24,1,1,1> > &in_stream,
		hls::stream<ap_axiu<24,1,1,1> >&out_stream,
		unsigned int height,
		unsigned int width,
		unsigned int order)
{
#pragma HLS DATAFLOW
#pragma HLS INTERFACE s_axilite port=return
#pragma HLS INTERFACE s_axilite port=order
#pragma HLS INTERFACE s_axilite port=width
#pragma HLS INTERFACE s_axilite port=height
#pragma HLS INTERFACE axis register both port=out_stream
#pragma HLS INTERFACE axis register both port=in_stream

	xf::Mat<XF_8UC3,HEIGHT, WIDTH,XF_NPPC1> img_in(height,width);
	xf::Mat<XF_8UC3,HEIGHT, WIDTH,XF_NPPC1> img_out(height,width);

	xf::Mat<XF_8UC1,HEIGHT, WIDTH,XF_NPPC1> img_gray_in(height,width);
	xf::Mat<XF_8UC1,HEIGHT, WIDTH,XF_NPPC1> img_gray_x(height,width);
	xf::Mat<XF_8UC1,HEIGHT, WIDTH,XF_NPPC1> img_gray_y(height,width);


	plainStream2xfMat<24,XF_8UC3,HEIGHT,WIDTH,XF_NPPC1>(in_stream,img_in);

	xf::xfrgb2gray<XF_8UC3, XF_8UC1, HEIGHT, WIDTH, XF_NPPC1, XF_WORDWIDTH(XF_8UC3,XF_NPPC1),XF_WORDWIDTH(XF_8UC1,XF_NPPC1), (WIDTH >> XF_BITSHIFT(XF_NPPC1)) >
	(img_in, img_gray_in, height,width);

	xf::Sobel<XF_BORDER_CONSTANT,XF_FILTER_3X3,XF_8UC1,XF_8UC1,HEIGHT,WIDTH,XF_NPPC1,false>
	(img_gray_in,img_gray_x,img_gray_y);

	select(img_gray_x,img_gray_y,img_out,order);

	xfMat2plainStream<24,XF_8UC3,HEIGHT,WIDTH,XF_NPPC1>(img_out,out_stream);


}
