// ==============================================================
// File generated on Tue Jul 21 14:01:42 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsobelx_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSobelx_accel_CfgInitialize(XSobelx_accel *InstancePtr, XSobelx_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSobelx_accel_Start(XSobelx_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_AP_CTRL) & 0x80;
    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSobelx_accel_IsDone(XSobelx_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSobelx_accel_IsIdle(XSobelx_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSobelx_accel_IsReady(XSobelx_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSobelx_accel_EnableAutoRestart(XSobelx_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_AP_CTRL, 0x80);
}

void XSobelx_accel_DisableAutoRestart(XSobelx_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_AP_CTRL, 0);
}

void XSobelx_accel_Set_height(XSobelx_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_HEIGHT_DATA, Data);
}

u32 XSobelx_accel_Get_height(XSobelx_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_HEIGHT_DATA);
    return Data;
}

void XSobelx_accel_Set_width(XSobelx_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_WIDTH_DATA, Data);
}

u32 XSobelx_accel_Get_width(XSobelx_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_WIDTH_DATA);
    return Data;
}

void XSobelx_accel_Set_order(XSobelx_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_ORDER_DATA, Data);
}

u32 XSobelx_accel_Get_order(XSobelx_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_ORDER_DATA);
    return Data;
}

void XSobelx_accel_InterruptGlobalEnable(XSobelx_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_GIE, 1);
}

void XSobelx_accel_InterruptGlobalDisable(XSobelx_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_GIE, 0);
}

void XSobelx_accel_InterruptEnable(XSobelx_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_IER);
    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_IER, Register | Mask);
}

void XSobelx_accel_InterruptDisable(XSobelx_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_IER);
    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_IER, Register & (~Mask));
}

void XSobelx_accel_InterruptClear(XSobelx_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSobelx_accel_WriteReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_ISR, Mask);
}

u32 XSobelx_accel_InterruptGetEnabled(XSobelx_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_IER);
}

u32 XSobelx_accel_InterruptGetStatus(XSobelx_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSobelx_accel_ReadReg(InstancePtr->Axilites_BaseAddress, XSOBELX_ACCEL_AXILITES_ADDR_ISR);
}

