#include "Canny_accel.h"
#include "opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "hls_opencv.h"
#include "hls_video.h"

int main(int argc, char** argv)
{
	static hls::stream<ap_axiu<24,1,1,1> >in_strm;
	static hls::stream<ap_axiu<24,1,1,1> >out_strm;
	char *path = "C:/Users/Siudya/Documents/HLSProj/Canny/data/lena.jpg";
	IplImage* in_img = cvLoadImage("C:/Users/Siudya/Documents/HLSProj/Canny/data/lena.jpg", 1);
	IplImage* out_img = cvCreateImage(cvGetSize(in_img), in_img->depth, in_img->nChannels);
	unsigned int imgwidth = 512;
	unsigned int imgheight = 512;

	printf("% d, %d\n",imgwidth,imgheight);

	for(int i = 0;i<imgheight;i++)
	{
		for(int j = 0;j<imgwidth;j++)
		{
			ap_axiu<24,1,1,1> temp;
			CvScalar s=cvGet2D(in_img, i, j);
			temp.data(7,0) = s.val[0];
			temp.data(15,8) = s.val[1];
			temp.data(23,16) = s.val[2];
			in_strm << temp;
		}
	}

	Canny_accel(in_strm,out_strm,imgheight,imgwidth,20,80);

	ap_axiu<24,1,1,1> temp;
	temp.last = 0;
	int counter = 0;
	while(temp.last == 0)
	{
		int i = counter / imgwidth;
		int j = counter % imgwidth;
		CvScalar s;
		out_strm >> temp;
		s.val[0] = temp.data(7,0);
		s.val[1] = temp.data(15,8);
		s.val[2] = temp.data(23,16);
		cvSet2D(out_img,i,j,s);
		counter ++;
	}

	cvShowImage("src",in_img);
	cvShowImage("res",out_img);
	cvWaitKey(0);

	cvReleaseImage(&in_img);
	cvReleaseImage(&out_img);

}
