#include "Sobel_accel.h"
#include "imgproc/xf_sobel.hpp"
#include "infra.h"
void drain(hls::stream<ap_uint<8> > & strm_in,short int height,short int width)
{
	ap_uint<8>val;
	for(int i = 0;i<height;i++)
	{
		for(int j=0;j<width;j++)
		{
			strm_in >> val;
		}
	}
}

void imgSelect(hls::stream<ap_uint<8> > & strm_in0,
		hls::stream<ap_uint<8> > & strm_in1,
		hls::Mat<HEIGHT,WIDTH,HLS_8UC1> & img_out,
		unsigned int order)
{
	if(order == 1)
	{
		plainStream2hlsMat_gray_inter(strm_in1,img_out);
		drain(strm_in0,img_out.rows,img_out.cols);
	}
	else
	{
		plainStream2hlsMat_gray_inter(strm_in0,img_out);
		drain(strm_in1,img_out.rows,img_out.cols);
	}
}

void Sobel_accel(hls::stream<ap_axiu<24,1,1,1> > &in_stream,
		hls::stream<ap_axiu<24,1,1,1> >&out_stream,
		unsigned int height,
		unsigned int width,
		unsigned int order)
{
#pragma HLS DATAFLOW
#pragma HLS INTERFACE s_axilite port=return
#pragma HLS INTERFACE s_axilite port=order
#pragma HLS INTERFACE s_axilite port=width
#pragma HLS INTERFACE s_axilite port=height
#pragma HLS INTERFACE axis register both port=out_stream
#pragma HLS INTERFACE axis register both port=in_stream

	hls::Mat<HEIGHT,WIDTH,HLS_8UC3> img_in(height,width);
	hls::Mat<HEIGHT,WIDTH,HLS_8UC1> img_gray_in(height,width);
	hls::Mat<HEIGHT,WIDTH,HLS_8UC1> img_gray_out(height,width);
	hls::Mat<HEIGHT,WIDTH,HLS_8UC3> img_out(height,width);
	hls::stream< XF_TNAME(XF_8UC1,XF_NPPC1)> _src;
	hls::stream< XF_TNAME(XF_8UC1,XF_NPPC1)> _dstx;
	hls::stream< XF_TNAME(XF_8UC1,XF_NPPC1)> _dsty;

	plainStream2hlsMat_rgb_port(in_stream,img_in);

	hls::CvtColor<HLS_RGB2GRAY, HLS_8UC3, HLS_8UC1>(img_in, img_gray_in);

	hlsMat2plainStream_gray_inter(img_gray_in,_src);

	xf::xFSobelFilter<
	WIDTH,HEIGHT,
	XF_CHANNELS(XF_8UC1,XF_NPPC1),
	XF_DEPTH(XF_8UC1,XF_NPPC1),
	XF_DEPTH(XF_8UC1,XF_NPPC1),
	XF_NPPC1,
	XF_WORDWIDTH(XF_8UC1,XF_NPPC1),
	XF_WORDWIDTH(XF_8UC1,XF_NPPC1),
	false >
	(_src,_dstx,_dsty,
	XF_FILTER_3X3,
	XF_BORDER_CONSTANT,
	height,width);

	imgSelect(_dstx,_dsty,img_gray_out,order);

	hls::CvtColor<HLS_GRAY2RGB, HLS_8UC1, HLS_8UC3>(img_gray_out, img_out);

	hlsMat2plainStream_rgb_port( img_out, out_stream);


}
